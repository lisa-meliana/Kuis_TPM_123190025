import 'package:flutter/cupertino.dart';

class SavedBook {
  final String id;
  final String title;
  final String authors;
  final String imageUrl;

  SavedBook(
      {@required this.id,
      @required this.title,
      @required this.authors,
      @required this.imageUrl});
}

// if you want source code please subscribe in my channel and contact me with my emil :
// brhomapps@gmail.com
// good luck and thanks //
